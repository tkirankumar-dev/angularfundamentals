import { Component } from '@angular/core';

@Component({
  selector: 'passenger-count',
  template: `
    <div>
      Count component
    </div>
  `
})
export class PassengerCountComponent {
  constructor() {}
}