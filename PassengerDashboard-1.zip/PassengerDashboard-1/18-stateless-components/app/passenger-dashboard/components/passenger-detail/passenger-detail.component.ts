import { Component } from '@angular/core';

@Component({
  selector: 'passenger-detail',
  template: `
    <div>
      Detail component
    </div>
  `
})
export class PassengerDetailComponent {
  constructor() {}
}